export declare const nodeId = "__adblock-extension-info";
export declare const datasetKey = "adblockExtensionInfo";
