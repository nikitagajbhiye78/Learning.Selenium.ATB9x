export declare const DefaultNotificationPermission = "default";
export declare const DeniedNotificationPermission = "denied";
export declare const GrantedNotificationPermission = "granted";
