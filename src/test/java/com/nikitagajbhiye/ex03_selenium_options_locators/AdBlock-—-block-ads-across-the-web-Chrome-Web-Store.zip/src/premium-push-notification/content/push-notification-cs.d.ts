declare const addDenyPushNotificationScript: () => void;
