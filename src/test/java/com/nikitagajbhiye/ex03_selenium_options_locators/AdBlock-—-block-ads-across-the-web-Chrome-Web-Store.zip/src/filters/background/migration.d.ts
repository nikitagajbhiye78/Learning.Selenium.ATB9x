export declare function start(): Promise<void>;
