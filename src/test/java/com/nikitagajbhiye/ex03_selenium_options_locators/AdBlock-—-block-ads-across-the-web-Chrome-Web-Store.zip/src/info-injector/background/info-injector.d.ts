import { type InjectionInfo } from "../shared";
export declare function getInjectionInfo(): Promise<InjectionInfo>;
