export default BirdChannel;
declare class BirdChannel extends Channel {
    getLatestListings(callback: any): void;
}
import Channel from "./channel";
