declare class DataCollectionV2 {
    static start: () => Promise<any>;
    static end: () => Promise<any>;
}
