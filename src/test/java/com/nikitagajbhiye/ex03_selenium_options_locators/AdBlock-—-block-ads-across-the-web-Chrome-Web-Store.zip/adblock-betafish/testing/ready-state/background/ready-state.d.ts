import { ReadyState } from "./ready-state.types";
export declare function setReadyState(newState: ReadyState): void;
export declare function getReadyState(): ReadyState;
