export default CatsChannel;
declare class CatsChannel extends Channel {
    getLatestListings(callback: any): void;
}
import Channel from "./channel";
