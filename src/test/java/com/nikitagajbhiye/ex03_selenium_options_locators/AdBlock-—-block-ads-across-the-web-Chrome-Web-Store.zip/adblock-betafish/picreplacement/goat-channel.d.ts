export default GoatsChannel;
declare class GoatsChannel extends Channel {
    getLatestListings(callback: any): void;
}
import Channel from "./channel";
