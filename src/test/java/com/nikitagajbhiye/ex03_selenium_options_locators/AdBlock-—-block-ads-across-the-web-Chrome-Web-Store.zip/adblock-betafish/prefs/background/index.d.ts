export const migrateUserData: () => Promise<void>;
export { getSettings, isValidTheme, setSetting, settings, settingsNotifier, start } from "./settings";
