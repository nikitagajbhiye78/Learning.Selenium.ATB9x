export default class PopupSection extends HTMLElement {
    connectedCallback(): Promise<void>;
    pageInfo: any;
}
