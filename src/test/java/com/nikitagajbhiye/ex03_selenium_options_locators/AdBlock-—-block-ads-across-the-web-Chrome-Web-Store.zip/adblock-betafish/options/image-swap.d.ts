declare let customImageSwapImageFormat: string;
