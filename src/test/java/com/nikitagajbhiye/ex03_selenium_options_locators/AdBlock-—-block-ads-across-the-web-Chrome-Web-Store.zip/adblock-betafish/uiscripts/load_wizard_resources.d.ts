declare function bindEnterClickToDefault($dialog: any): void;
declare function loadWizardResources($base: any, callback: any): void;
