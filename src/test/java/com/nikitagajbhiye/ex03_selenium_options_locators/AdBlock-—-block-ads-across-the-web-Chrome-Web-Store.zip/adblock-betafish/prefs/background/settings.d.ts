export function start(): void;
export let settingsNotifier: any;
export let settings: any;
export function getSettings(): any;
export function setSetting(name: any, isEnabled: any, callback: any): void;
export function isValidTheme(themeName: any): boolean;
