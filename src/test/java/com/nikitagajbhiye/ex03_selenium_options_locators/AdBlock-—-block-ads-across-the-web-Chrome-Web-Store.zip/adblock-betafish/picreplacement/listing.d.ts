export default Listing;
declare class Listing {
    constructor(data: any);
    width: any;
    height: any;
    url: any;
    title: any;
    attributionUrl: any;
    channelName: any;
    name: any;
    thumbURL: any;
    userLink: any;
    anySize: any;
    type: any;
    ratio: any;
    customImage: any;
}
