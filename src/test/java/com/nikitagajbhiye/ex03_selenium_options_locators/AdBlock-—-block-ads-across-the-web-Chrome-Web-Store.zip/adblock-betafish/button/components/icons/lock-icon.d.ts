export default LockIcon;
declare const LockIcon: string;
