export default class ActionButton extends HTMLElement {
    connectedCallback(): Promise<void>;
    pageInfo: any;
}
