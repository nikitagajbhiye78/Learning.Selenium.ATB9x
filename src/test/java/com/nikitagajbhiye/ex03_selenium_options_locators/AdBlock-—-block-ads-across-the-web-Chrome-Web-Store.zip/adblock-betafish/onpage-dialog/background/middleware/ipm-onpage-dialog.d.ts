import { type CommandHandler } from "../../../ipm/background";
export declare function setDialogCommandHandler(handler: CommandHandler): void;
