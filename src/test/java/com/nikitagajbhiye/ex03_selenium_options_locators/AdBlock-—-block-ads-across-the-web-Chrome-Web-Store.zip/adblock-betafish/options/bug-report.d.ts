declare let debugInfo: any;
declare let textDebugInfo: string;
declare let extInfo: string;
declare function bugReportLogic(): Promise<void>;
