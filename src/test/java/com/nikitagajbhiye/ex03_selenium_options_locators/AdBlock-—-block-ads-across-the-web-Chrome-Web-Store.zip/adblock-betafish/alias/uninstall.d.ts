export function getExperiments(): string;
export function setUninstallURL(): Promise<void>;
