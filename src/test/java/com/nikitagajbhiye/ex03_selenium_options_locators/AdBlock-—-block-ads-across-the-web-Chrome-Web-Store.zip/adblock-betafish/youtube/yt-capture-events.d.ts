declare function captureYTEvents({ toContentScriptEventName }: {
    toContentScriptEventName: any;
}): void;
declare function initWithParams(): void;
declare function start(): void;
