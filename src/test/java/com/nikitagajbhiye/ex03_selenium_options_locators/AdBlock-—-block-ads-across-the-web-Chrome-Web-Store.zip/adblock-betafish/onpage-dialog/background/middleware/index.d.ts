export * from "./ipm-onpage-dialog";
export * from "./ipm-onpage-dialog.types";
