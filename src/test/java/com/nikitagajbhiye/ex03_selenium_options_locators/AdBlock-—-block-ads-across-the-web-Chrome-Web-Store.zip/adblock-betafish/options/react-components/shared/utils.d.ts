export function translate(messageName: any, substitutions: any, VERBOSE_DEBUG?: boolean): string;
