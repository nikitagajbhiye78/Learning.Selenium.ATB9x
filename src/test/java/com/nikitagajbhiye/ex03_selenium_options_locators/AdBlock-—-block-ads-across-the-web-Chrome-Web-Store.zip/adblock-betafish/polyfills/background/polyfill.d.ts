import { FilterMetadata } from "./polyfill.types";
export declare function isFilterMetadata(candidate: unknown): candidate is FilterMetadata;
