export declare function getUserId(): Promise<string>;
