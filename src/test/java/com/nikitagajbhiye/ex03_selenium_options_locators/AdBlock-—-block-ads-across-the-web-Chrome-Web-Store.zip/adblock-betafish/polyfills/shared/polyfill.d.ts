import { Message } from "./polyfill.types";
export declare function isMessage(candidate: unknown): candidate is Message;
