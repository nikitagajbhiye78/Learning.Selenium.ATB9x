export const imageSizesMap: Map<string, number>;
export const WIDE: number | undefined;
export const TALL: number | undefined;
export const BIG: number | undefined;
export const SMALL: number | undefined;
export const SKINNYWIDE: number | undefined;
export const SKINNYTALL: number | undefined;
