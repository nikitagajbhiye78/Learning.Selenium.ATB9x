export interface Stats {
    displayCount: number;
    lastDisplayTime: number;
}
