export default LandscapesChannel;
declare class LandscapesChannel extends Channel {
    getLatestListings(callback: any): void;
}
import Channel from "./channel";
