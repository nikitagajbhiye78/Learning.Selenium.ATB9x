declare function topOpenWhitelistCompletionUI(options: any): void;
