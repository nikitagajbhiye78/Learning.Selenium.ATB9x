export default class PopupDetailStats extends HTMLElement {
    connectedCallback(): Promise<void>;
    pageInfo: any;
}
