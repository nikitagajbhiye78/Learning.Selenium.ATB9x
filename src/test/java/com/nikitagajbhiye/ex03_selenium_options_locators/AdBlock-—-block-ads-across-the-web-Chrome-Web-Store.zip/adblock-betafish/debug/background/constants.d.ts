export const IPM_CONSTANTS: string[];
export const NO_DATA: "no data";
