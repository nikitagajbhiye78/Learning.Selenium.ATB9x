Bundled Library versions:

DomPurify
https://github.com/cure53/DOMPurify/releases/tag/3.0.11

ChartJS
https://github.com/chartjs/Chart.js/releases/tag/v2.9.4

jQuery
https://code.jquery.com/jquery-3.5.1.min.js
